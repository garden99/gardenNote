# nginx进行https配置就和node感觉差不多，也是拿到这两个文件就差不多了

将配置项进行如下编辑就可，最顶层的http不需要改成https

![1726048387587](images/https配置/1726048387587.png)
